package com.example.prodanapp

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.prodanapp.databinding.FragmentFormBinding

class FormFragment : Fragment() {

    private var _binding: FragmentFormBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentFormBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val preferences = requireActivity().getPreferences(Context.MODE_PRIVATE)
        val aceptado = preferences.getBoolean("aviso", false)

        setPreferences()

        if (!aceptado){
            var dialog = TermsFragment()

            dialog.show(parentFragmentManager, "customDialog")
            dialog.isCancelable = false
        }



        binding.buttonConfirm.setOnClickListener{
         savePreferences()
            findNavController().navigate(R.id.action_formFragment_to_mainviewFragment)
        }
    }

    fun savePreferences(){
        val preferences = requireActivity().getPreferences(Context.MODE_PRIVATE)
        with(preferences.edit()){
            putBoolean("pregunta1", binding.Pregunta1.isChecked)
            putBoolean("pregunta2", binding.Pregunta2.isChecked)
            putBoolean("pregunta3", binding.Pregunta3.isChecked)
            putBoolean("pregunta4", binding.Pregunta4.isChecked)
            putBoolean("pregunta5", binding.Pregunta5.isChecked)
            commit()
        }
    }

    fun setPreferences(){
        val preferences = requireActivity().getPreferences(Context.MODE_PRIVATE)


        binding.Pregunta1.isChecked = preferences.getBoolean("pregunta1", false)
        binding.Pregunta2.isChecked = preferences.getBoolean("pregunta2", false)
        binding.Pregunta3.isChecked = preferences.getBoolean("pregunta3", false)
        binding.Pregunta4.isChecked = preferences.getBoolean("pregunta4", false)
        binding.Pregunta5.isChecked = preferences.getBoolean("pregunta5", false)
    }

}