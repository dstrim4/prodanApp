package com.example.prodanapp.data

object Constants{
    const val BASE_URL = "https://powerful-basin-43504.herokuapp.com/api/"
    const val API_TOKEN = "3a99d38d154e2962f77887f781253f521fcf26b44a9e4c03456ad8ef3c79996e852867c022bc8f8f3da4341eef20928784fdde6450f67c358d12ffb1139081b170acc26859a33a1b3fa868b40ae9fe92e50efcfa701b9cbc6f688274d375f5fe4f6a44e3c4a973b6a907ab58b79ce4ce49e05b5f8bfb3318ad3f58f2818baa1e"
}
